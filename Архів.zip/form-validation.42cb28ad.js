// modules are defined as an array
// [ module function, map of requires ]
//
// map of requires is short require name -> numeric require
//
// anything defined in a previous bundle is accessed via the
// orig method which is the require for previous bundles
parcelRequire = (function (modules, cache, entry, globalName) {
  // Save the require from previous bundle to this closure if any
  var previousRequire = typeof parcelRequire === 'function' && parcelRequire;
  var nodeRequire = typeof require === 'function' && require;

  function newRequire(name, jumped) {
    if (!cache[name]) {
      if (!modules[name]) {
        // if we cannot find the module within our internal map or
        // cache jump to the current global require ie. the last bundle
        // that was added to the page.
        var currentRequire = typeof parcelRequire === 'function' && parcelRequire;
        if (!jumped && currentRequire) {
          return currentRequire(name, true);
        }

        // If there are other bundles on this page the require from the
        // previous one is saved to 'previousRequire'. Repeat this as
        // many times as there are bundles until the module is found or
        // we exhaust the require chain.
        if (previousRequire) {
          return previousRequire(name, true);
        }

        // Try the node require function if it exists.
        if (nodeRequire && typeof name === 'string') {
          return nodeRequire(name);
        }

        var err = new Error('Cannot find module \'' + name + '\'');
        err.code = 'MODULE_NOT_FOUND';
        throw err;
      }

      localRequire.resolve = resolve;
      localRequire.cache = {};

      var module = cache[name] = new newRequire.Module(name);

      modules[name][0].call(module.exports, localRequire, module, module.exports, this);
    }

    return cache[name].exports;

    function localRequire(x){
      return newRequire(localRequire.resolve(x));
    }

    function resolve(x){
      return modules[name][1][x] || x;
    }
  }

  function Module(moduleName) {
    this.id = moduleName;
    this.bundle = newRequire;
    this.exports = {};
  }

  newRequire.isParcelRequire = true;
  newRequire.Module = Module;
  newRequire.modules = modules;
  newRequire.cache = cache;
  newRequire.parent = previousRequire;
  newRequire.register = function (id, exports) {
    modules[id] = [function (require, module) {
      module.exports = exports;
    }, {}];
  };

  var error;
  for (var i = 0; i < entry.length; i++) {
    try {
      newRequire(entry[i]);
    } catch (e) {
      // Save first error but execute all entries
      if (!error) {
        error = e;
      }
    }
  }

  if (entry.length) {
    // Expose entry point to Node, AMD or browser globals
    // Based on https://github.com/ForbesLindesay/umd/blob/master/template.js
    var mainExports = newRequire(entry[entry.length - 1]);

    // CommonJS
    if (typeof exports === "object" && typeof module !== "undefined") {
      module.exports = mainExports;

    // RequireJS
    } else if (typeof define === "function" && define.amd) {
     define(function () {
       return mainExports;
     });

    // <script>
    } else if (globalName) {
      this[globalName] = mainExports;
    }
  }

  // Override the current require with this new one
  parcelRequire = newRequire;

  if (error) {
    // throw error from earlier, _after updating parcelRequire_
    throw error;
  }

  return newRequire;
})({"gcEx":[function(require,module,exports) {
// Отримати посилання на форму
var form = document.querySelector("form");

// Обробка події надсилання форми
form.addEventListener("submit", function (event) {
  event.preventDefault(); // Перехопити відправку форми

  // Отримати значення полів вводу
  var usernameInput = document.getElementById("username-input");
  var phoneInput = document.getElementById("phone-input");

  // Отримати значення полів вводу
  var usernameValue = usernameInput.value.trim();
  var phoneValue = phoneInput.value.trim();

  // Перевірка, чи не є поля порожніми
  if (usernameValue === "") {
    showError(usernameInput, "Будь ласка, введіть ваше ім'я");
  } else if (!/^[a-zA-Z]+[а-яА-Я]$/.test(usernameValue)) {
    showError(usernameInput, "Будь ласка, введіть лише латинські букви");
  } else if (phoneValue === "") {
    showError(phoneInput, "Будь ласка, введіть ваш номер телефону");
  } else if (!/^\d+$/.test(phoneValue)) {
    showError(phoneInput, "Будь ласка, введіть лише цифри");
  } else {
    // Форма пройшла валідацію, можна відправити форму
    form.submit();
  }
});

// Відобразити повідомлення про помилку
function showError(input, message) {
  // Отримати контейнер для повідомлення про помилку
  var errorContainer = input.parentNode.querySelector(".error-message");

  // Перевірка, чи вже відображається повідомлення про помилку
  if (errorContainer) {
    // Оновити повідомлення про помилку
    errorContainer.textContent = message;
  } else {
    // Створити новий контейнер для повідомлення про помилку
    var newErrorContainer = document.createElement("div");
    newErrorContainer.classList.add("error-message");
    newErrorContainer.textContent = message;

    // Вставити контейнер перед полем вводу
    input.parentNode.insertBefore(newErrorContainer, input);
  }

  // Додати клас помилки до поля вводу
  input.classList.add("error");
}

// Видалити повідомлення після вірного введення
form.addEventListener("input", function (e) {
  var input = e.target;
  var errorContainer = input.parentNode.querySelector(".error-message");
  if (errorContainer) {
    // видаляємо повідомлення про помилку
    errorContainer.remove();
    // Видаляємо клас помилки
    input.classList.remove("error");
  }
});
},{}]},{},["gcEx"], null)
//# sourceMappingURL=/form-validation.42cb28ad.js.map